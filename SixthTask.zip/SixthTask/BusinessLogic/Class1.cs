﻿namespace BusinessLogic
{
    public class Class1
    {

    }
}